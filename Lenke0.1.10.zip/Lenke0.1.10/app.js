$(document).ready(function() {
$(".cambiosize").click(function redimensionarDiv(){
    var displayaout = 'visible'
    var paddingBottom = '63vh'
    var listradioout1 = 'none'
    var listradioout2 = 'none'
    var listradioout3 = 'block'
    $(".map-container-4").css({"height": paddingBottom});
    $("#todisplayn").css({"visibility": displayaout}) 
    $("#listradio1").css({"display": listradioout1})
    $("#listradio2").css({"display": listradioout2})
    $("#listradio3").css({"display": listradioout3})
});

$(".cambiosize2").click(function redimensionarDiv(){
    var againdisplayn = 'hidden'
    var paddingBottom = '100vh'
    $(".map-container-4").css({"height": paddingBottom});
    $("#todisplayn").css({"visibility": againdisplayn});
    
});
$(".backgroundselectionbutton").click(function redimensionarDiv(){
    var listradioout11 = 'block'
    var listradioout22 = 'none'
    var listradioout33 = 'none'
    $("#listradio1").css({"display": listradioout11})
    $("#listradio2").css({"display": listradioout22})
    $("#listradio3").css({"display": listradioout33})
    
});
$(".ehtiopiaregionsbutton").click(function redimensionarDiv(){
    var listradioout111 = 'none'
    var listradioout222 = 'block'
    var listradioout333 = 'none'
    $("#listradio1").css({"display": listradioout111})
    $("#listradio2").css({"display": listradioout222})
    $("#listradio3").css({"display": listradioout333})
});


$('.date-j').datepicker({
});

document.getElementById( 'backgroundbutton' ).onclick = select_background_map();
document.getElementById( 'ethiopiabutton' ).onclick = select_regions_of_ethiopia();
document.getElementById( 'waterbodiesbutton' ).onclick = select_wáter_bodies();
document.getElementById( 'farmdbutton' ).onclick = select_farm();
document.getElementById( 'uploaddrawedbutton' ).onclick = upload_drawed_polygon();
document.getElementById( 'regionsethiopiabutton' ).onclick = change_regions_of_ethiopia_color(Black/White);
document.getElementById( 'downloadforecastbutton' ).onclick = download_forecast_file(csv_path);
document.getElementById( 'downloadsentinelbutton' ).onclick = download_sentinel_hub_maps(tiff_path)();
document.getElementById( 'homepagebutton' ).onclick = set_homepage();

});
function statusbutton()
{
    var elem = document.getElementById("myButton1");
    var elem2 = document.getElementById("myButton2");

    if (elem.value=="Moisture" && elem2.value=="Forecast"){
    elem2.value = "Historic";
    elem.value = "Satelite";}
    else
    if(elem.value=="Satelite" && elem2.value=="Historic")
    elem.value = "Moisture";
    else
    if(elem.value=="Moisture" && elem2.value=="Historic")
    elem.value = "Satelite";
    
}
function statusbutton2()
{
    var elem = document.getElementById("myButton1");
    var elem2 = document.getElementById("myButton2");

    if (elem.value=="Moisture" && elem2.value=="Forecast")
    elem2.value = "Historic";
    else
    if(elem.value=="Moisture" && elem2.value=="Historic")
    elem2.value = "Forecast";

}

$(document).ready(function() {
    var date = new Date();

    var day = date.getDate();
    var month = date.getMonth() + 1;
    var year = date.getFullYear();

    if (month < 10) month = "0" + month;
    if (day < 10) day = "0" + day;

    var today = year + "-" + month + "-" + day;       
    $("#actualdate").attr("value", today);
});
$(document).ready(function() {
    var date = new Date();

    var day = date.getDate();
    var month = date.getMonth() + 1;
    var year = date.getFullYear();

    if (month < 10) month = "0" + month;
    if (day < 10) day = "0" + day;

    var today = year + "-" + month + "-" + day;       
    $("#actualdate2").attr("value", today);
});
$(document).ready(function() {
    var date = new Date();

    var day = date.getDate();
    var month = date.getMonth() + 1;
    var year = date.getFullYear();

    if (month < 10) month = "0" + month;
    if (day < 10) day = "0" + day;
    
    var today = year + "-" + month + "-" + day;       
    $("#actualdate3").attr("value", today);
});
