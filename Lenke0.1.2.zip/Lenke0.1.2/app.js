$(document).ready(function() {
$(".cambiosize").click(function redimensionarDiv(){
    var paddingBottom = '75vh'
    $(".map-container-4").css({"height": paddingBottom});
    
});
$(".cambiosize2").click(function redimensionarDiv(){
    var paddingBottom = '100vh'
    $(".map-container-4").css({"height": paddingBottom});
    
});
$('.date-j').datepicker({
});

document.getElementById( 'backgroundbutton' ).onclick = select_background_map();
document.getElementById( 'ethiopiabutton' ).onclick = select_regions_of_ethiopia();
document.getElementById( 'waterbodiesbutton' ).onclick = select_wáter_bodies();
document.getElementById( 'farmdbutton' ).onclick = select_farm();
document.getElementById( 'uploaddrawedbutton' ).onclick = upload_drawed_polygon();
document.getElementById( 'regionsethiopiabutton' ).onclick = change_regions_of_ethiopia_color(Black/White);
document.getElementById( 'downloadforecastbutton' ).onclick = download_forecast_file(csv_path);
document.getElementById( 'downloadsentinelbutton' ).onclick = download_sentinel_hub_maps(tiff_path)();
document.getElementById( 'homepagebutton' ).onclick = set_homepage();

});
